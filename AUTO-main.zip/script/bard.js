const axios = require('axios');

module.exports.config = {
  name: 'bard',
  version: '1.0.0',
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, type, messageReply, body } = event;
  let question = "";

  if (type === "message_reply" && messageReply.attachments[0]?.type === "photo") {
    const attachment = messageReply.attachments[0];
    const imageURL = attachment.url;
    question = await convertImageToText(imageURL);

    if (!question) {
      api.sendMessage(
        "❌ Failed to convert the photo to text. Please try again with a clearer photo.",
        threadID,
        messageID
      );
      return;
    }
  } else {
    question = args.join(' ');

    if (!question) {
      api.sendMessage("Please provide a question or query", threadID, messageID);
      return;
    }
  }

  try {
    const apiBaseUrl = 'http://api.safone.me';
    const apiEndpoint = '/bard';
    const apiUrl = apiBaseUrl + apiEndpoint;

    console.log('API URL:', apiUrl);
    console.log('Question sent:', question);

    const response = await axios.get(apiUrl, { params: { message: question } });
    const responseData = response.data;

    const responseMessage = responseData.message;

    console.log('API response:', responseMessage);

    api.sendMessage(responseMessage, threadID);
  } catch (error) {
    console.error('Error during the API request:', error);
    api.sendMessage('Sorry, an error occurred while communicating with the conversation AI.', threadID);
  }
};